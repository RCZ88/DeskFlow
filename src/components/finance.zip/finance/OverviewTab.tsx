import { useState, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Wallet, TrendingUp, TrendingDown, Receipt,
  ArrowUpRight, ArrowDownLeft, ArrowLeftRight, Plus, Check,
} from 'lucide-react';
import {
  Chart as ChartJS,
  CategoryScale, LinearScale, BarElement,
  PointElement, LineElement,
  ArcElement, Tooltip, Legend, Filler,
} from 'chart.js';
import { Doughnut, Bar } from 'react-chartjs-2';
import { GlassSurface } from './_fx/GlassSurface';
import { pageContainer, riseItem } from './_fx/financeMotion';
import { CHART_AXIS, ChartDefs } from './_fx/ChartTheme';
import { EmptyState } from './EmptyState';
import { formatCurrency as fc, convertAmount } from './currency-data';
import { useNumberMask } from '../../context/NumberMaskContext';
import { maskNumber } from '../../utils/maskNumber';
import type {
  FinanceAccount, FinanceWallet, FinanceCategory, FinanceTransaction,
  FinanceSummary, FinanceSpendingByCategory, FinanceMonthlyTrend,
} from './finance-types';

ChartJS.register(CategoryScale, LinearScale, BarElement, PointElement, LineElement, ArcElement, Tooltip, Legend, Filler);

interface OverviewTabProps {
  summary: FinanceSummary | null;
  spendingByCategory: FinanceSpendingByCategory[];
  monthlyTrends: FinanceMonthlyTrend[];
  accounts: FinanceAccount[];
  recentTransactions: FinanceTransaction[];
  categories: FinanceCategory[];
  wallets: FinanceWallet[];
  loading: boolean;
  error?: string | null;
  onRetry?: () => void;
  displayCurrency: string;
  baseCurrency: string;
  onCreateAccount?: (data: {
    name: string; type: FinanceAccount['type']; description?: string;
    icon?: string; color?: string; currency?: string; balance?: number;
  }) => Promise<boolean>;
  onAddTransaction: (data: {
    account_id: number; wallet_id: number | null; category_id: number;
    type: 'income' | 'expense' | 'transfer'; amount: number;
    description: string; note: string; date: string;
  }) => Promise<boolean>;
}

type TxnType = 'income' | 'expense' | 'transfer';

function Sparkline({ data, color }: { data: number[]; color: string }) {
  if (!data.length) return null;
  const max = Math.max(...data, 1);
  const min = Math.min(...data, 0);
  const range = max - min || 1;
  const w = 96;
  const h = 32;
  const points = data.map((v, i) => {
    const x = (i / (data.length - 1 || 1)) * w;
    const y = h - ((v - min) / range) * h;
    return `${x},${y}`;
  }).join(' ');

  return (
    <svg width={w} height={h} className="absolute bottom-1 right-1 opacity-15 pointer-events-none" viewBox={`0 0 ${w} ${h}`}>
      <polyline fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" points={points} />
    </svg>
  );
}

export function OverviewTab({
  summary, spendingByCategory, monthlyTrends, accounts, recentTransactions,
  categories, wallets, loading, error, onRetry, displayCurrency, baseCurrency,
  onCreateAccount, onAddTransaction,
}: OverviewTabProps) {
  const { showNumbers, maskMode, maskFixedValue } = useNumberMask();
  const fcc = (amount: number) => fc(convertAmount(amount, baseCurrency, displayCurrency), displayCurrency);

  const [qaType, setQaType] = useState<TxnType>('expense');
  const [qaAmount, setQaAmount] = useState('');
  const [qaDescription, setQaDescription] = useState('');
  const [qaAccountId, setQaAccountId] = useState<number>(accounts[0]?.id ?? 0);
  const [qaCategoryId, setQaCategoryId] = useState<number>(0);
  const [qaSubmitting, setQaSubmitting] = useState(false);
  const [qaSuccess, setQaSuccess] = useState(false);

  const activeAccounts = useMemo(() => accounts.filter(a => !a.is_archived), [accounts]);
  const activeWallets = useMemo(() => wallets.filter(w => !w.is_archived), [wallets]);

  const filteredCategories = useMemo(
    () => categories.filter(c => !c.is_archived && c.type === qaType),
    [categories, qaType],
  );

  const firstCategoryId = useMemo(
    () => filteredCategories[0]?.id ?? 0,
    [filteredCategories],
  );

  const handleQuickAdd = useCallback(async () => {
    const amount = parseFloat(qaAmount);
    if (!amount || !qaDescription.trim() || !qaAccountId) return;
    setQaSubmitting(true);
    const ok = await onAddTransaction({
      account_id: qaAccountId,
      wallet_id: null,
      category_id: qaCategoryId || firstCategoryId,
      type: qaType,
      amount: qaType === 'expense' ? -Math.abs(amount) : Math.abs(amount),
      description: qaDescription.trim(),
      note: '',
      date: new Date().toISOString().slice(0, 10),
    });
    setQaSubmitting(false);
    if (ok) {
      setQaSuccess(true);
      setQaAmount('');
      setQaDescription('');
      setTimeout(() => setQaSuccess(false), 1500);
    }
  }, [qaAmount, qaDescription, qaAccountId, qaCategoryId, firstCategoryId, qaType, onAddTransaction]);

  const barData = useMemo(() => {
    if (!monthlyTrends.length) return null;
    const last6 = monthlyTrends.slice(-6);
    return {
      labels: last6.map(m => m.month),
      datasets: [
        {
          label: 'Income',
          data: last6.map(m => convertAmount(m.income, baseCurrency, displayCurrency)),
          backgroundColor: 'rgba(52, 211, 153, 0.7)',
          borderColor: 'rgba(52, 211, 153, 1)',
          borderWidth: 1,
          borderRadius: 6,
          barThickness: 20,
        },
        {
          label: 'Expense',
          data: last6.map(m => convertAmount(m.expense, baseCurrency, displayCurrency)),
          backgroundColor: 'rgba(248, 113, 113, 0.7)',
          borderColor: 'rgba(248, 113, 113, 1)',
          borderWidth: 1,
          borderRadius: 6,
          barThickness: 20,
        },
      ],
    };
  }, [monthlyTrends, baseCurrency, displayCurrency]);

  const doughnutData = useMemo(() => {
    if (!spendingByCategory.length) return null;
    const top = spendingByCategory.slice(0, 7);
    const colors = top.map(c => c.categoryColor || '#71717a');
    const labels = top.map(c => c.categoryName);
    if (spendingByCategory.length > 7) {
      const other = spendingByCategory.slice(7).reduce((s, c) => s + c.amount, 0);
      labels.push('Other');
      colors.push('#52525b');
      top.push({ categoryName: 'Other', amount: other, percentage: 0, categoryId: 0, categoryColor: '#52525b', categoryIcon: '' });
    }
    return {
      labels,
      datasets: [{
        data: top.map(c => convertAmount(c.amount, baseCurrency, displayCurrency)),
        backgroundColor: colors,
        borderWidth: 0,
        cutout: '68%',
      }],
    };
  }, [spendingByCategory, baseCurrency, displayCurrency]);

  if (loading) {
    return (
      <div className="grid grid-cols-4 gap-4">
        {[1,2,3,4].map(i => (
          <div key={i} className="animate-pulse bg-zinc-800/60 rounded-[20px] h-32" />
        ))}
        <div className="col-span-4 grid grid-cols-2 gap-4">
          {[1,2].map(i => (
            <div key={i} className="animate-pulse bg-zinc-800/60 rounded-[20px] h-64" />
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-5 space-y-4">
        <div className="bg-red-500/10 border border-red-500/30 rounded-[20px] p-5 text-center">
          <p className="text-sm text-red-400 mb-2">{error}</p>
          {onRetry && (
            <button
              onClick={onRetry}
              className="px-4 py-2 rounded-lg bg-red-500/15 text-red-400 hover:bg-red-500/25 text-xs font-medium transition-colors focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950"
            >
              Retry
            </button>
          )}
        </div>
      </div>
    );
  }

  if (!activeAccounts.length) {
    return (
      <EmptyState
        icon={<Wallet className="w-12 h-12" />}
        title="No accounts yet"
        description="Create your first account to start tracking your finances"
        action={onCreateAccount ? { label: 'Create Account', onClick: () => onCreateAccount({ name: 'New Account', type: 'personal', currency: displayCurrency, balance: 0 }) } : undefined}
      />
    );
  }

  const typeColor = (t: TxnType) => t === 'income' ? 'emerald' : t === 'expense' ? 'red' : 'amber';
  const typeIcon = (t: TxnType) => t === 'income' ? ArrowUpRight : t === 'expense' ? ArrowDownLeft : ArrowLeftRight;
  const TypeIcon = typeIcon(qaType);

  const kpiData = [
    { label: 'Income', value: summary?.totalIncome ?? 0, icon: TrendingUp, color: 'text-emerald-400', sparkColor: '#34d399' },
    { label: 'Expenses', value: summary?.totalExpense ?? 0, icon: TrendingDown, color: 'text-red-400', sparkColor: '#fb7185' },
    { label: 'Net Worth', value: summary?.netBalance ?? 0, icon: Wallet, color: (summary?.netBalance ?? 0) >= 0 ? 'text-emerald-400' : 'text-red-400', sparkColor: '#10b981' },
    { label: 'Transactions', value: recentTransactions.length, icon: Receipt, color: 'text-zinc-300', sparkColor: '#a1a1aa' },
  ];

  const personalAccounts = activeAccounts.filter(a => a.type !== 'custodial');
  const custodialAccounts = activeAccounts.filter(a => a.type === 'custodial');

  return (
    <motion.div
      variants={pageContainer}
      initial="hidden"
      animate="show"
      className="grid grid-cols-1 gap-6"
    >
      <ChartDefs />

      {/* QuickAddBar */}
      <motion.div variants={riseItem}>
        <GlassSurface className="p-4">
          <div className="flex flex-wrap items-end gap-3">
            <div className="flex gap-1 bg-zinc-800/60 rounded-lg p-0.5">
              {(['income', 'expense', 'transfer'] as TxnType[]).map(t => {
                const Icon = typeIcon(t);
                const isActive = qaType === t;
                const activeClass = t === 'income' ? 'bg-emerald-500/20 text-emerald-400' : t === 'expense' ? 'bg-red-500/20 text-red-400' : 'bg-amber-500/20 text-amber-400';
                return (
                  <button
                    key={t}
                    onClick={() => { setQaType(t); setQaCategoryId(0); }}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                      isActive ? activeClass : 'text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    {t.charAt(0).toUpperCase() + t.slice(1)}
                  </button>
                );
              })}
            </div>
            <div className="relative flex-1 min-w-[140px] max-w-[200px]">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-zinc-400">$</span>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-full bg-zinc-800/80 border border-zinc-700/50 rounded-lg pl-7 pr-3 py-2 text-sm font-bold tabular-nums text-white placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
              />
            </div>
            <input
              type="text"
              value={qaDescription}
              onChange={(e) => setQaDescription(e.target.value)}
              placeholder="Description"
              className="flex-1 min-w-[140px] max-w-[240px] bg-zinc-800/80 border border-zinc-700/50 rounded-lg px-3 py-2 text-sm text-white placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
            />
            <select
              value={qaAccountId}
              onChange={(e) => setQaAccountId(parseInt(e.target.value))}
              className="bg-zinc-800/80 border border-zinc-700/50 rounded-lg px-3 py-2 text-sm text-zinc-300 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 min-w-[120px]"
            >
              {activeAccounts.map(a => (
                <option key={a.id} value={a.id}>{a.name}</option>
              ))}
            </select>
            <button
              onClick={handleQuickAdd}
              disabled={qaSubmitting || !qaAmount || !qaDescription.trim()}
              className={`px-4 py-2 rounded-lg text-xs font-medium transition-colors disabled:opacity-40 flex items-center gap-1.5 focus-visible:ring-2 ring-emerald-500/50 ${
                qaType === 'income'
                  ? 'bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30'
                  : qaType === 'expense'
                    ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30'
                    : 'bg-amber-500/20 text-amber-400 hover:bg-amber-500/30'
              }`}
            >
              {qaSubmitting ? (
                <div className="w-3.5 h-3.5 border-2 border-current border-t-transparent rounded-full animate-spin" />
              ) : qaSuccess ? (
                <Check className="w-3.5 h-3.5" />
              ) : (
                <Plus className="w-3.5 h-3.5" />
              )}
              {qaSuccess ? 'Added' : 'Add'}
            </button>
          </div>
          {filteredCategories.length > 0 && (
            <div className="mt-3 flex gap-1.5 overflow-x-auto pb-0.5 scrollbar-thin">
              {filteredCategories.map(c => (
                <button
                  key={c.id}
                  onClick={() => setQaCategoryId(prev => prev === c.id ? 0 : c.id)}
                  className={`shrink-0 flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-medium transition-colors border ${
                    qaCategoryId === c.id
                      ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300'
                      : 'bg-zinc-800/50 border-zinc-700/30 text-zinc-400 hover:text-zinc-200 hover:border-zinc-600/50'
                  }`}
                >
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: c.color }} />
                  {c.name}
                </button>
              ))}
            </div>
          )}
        </GlassSurface>
      </motion.div>

      {/* KPI Cards */}
      <motion.div variants={riseItem} className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {kpiData.map(kpi => {
          const Icon = kpi.icon;
          const displayVal = typeof kpi.value === 'number'
            ? (showNumbers
                ? fcc(kpi.value)
                : maskNumber(fcc(kpi.value), maskMode, maskFixedValue))
            : String(kpi.value);
          return (
            <GlassSurface key={kpi.label} className="p-4 relative overflow-hidden">
              <Sparkline data={monthlyTrends.map(m => kpi.label === 'Income' ? m.income : kpi.label === 'Expenses' ? m.expense : m.net).filter(v => v !== undefined)} color={kpi.sparkColor} />
              <div className="flex items-center gap-2 mb-2">
                <Icon className={`w-4 h-4 ${kpi.color}`} />
                <span className="text-[11px] font-medium text-zinc-500">{kpi.label}</span>
              </div>
              <p className={`text-xl font-bold tabular-nums ${kpi.color}`}>
                {displayVal}
              </p>
            </GlassSurface>
          );
        })}
      </motion.div>

      {/* Charts */}
      <motion.div variants={riseItem} className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <GlassSurface className="p-5">
          <span className="text-[11px] font-semibold tracking-[0.08em] uppercase text-zinc-500">
            Spending by Category
          </span>
          <div className="mt-3">
            {!doughnutData ? (
              <div className="flex flex-col items-center justify-center py-10 text-zinc-600">
                <Wallet className="w-8 h-8 mb-2 opacity-30" />
                <span className="text-xs">No spending this period</span>
              </div>
            ) : (
              <div className="flex items-center justify-center">
                <div className="w-[220px]">
                  <Doughnut
                    data={doughnutData}
                    options={{
                      responsive: true,
                      maintainAspectRatio: true,
                      plugins: {
                        legend: {
                          position: 'right',
                          labels: { color: '#a1a1aa', font: { size: 10 }, padding: 8, usePointStyle: true, pointStyleWidth: 8 },
                        },
                        tooltip: {
                          backgroundColor: 'rgba(24, 24, 27, 0.95)',
                          titleColor: '#e4e4e7',
                          bodyColor: '#a1a1aa',
                          borderColor: 'rgba(63, 63, 70, 0.5)',
                          borderWidth: 1,
                          cornerRadius: 8,
                          padding: 10,
                          callbacks: {
                            label: (ctx) => {
                              const val = ctx.parsed as number;
                              return ` ${ctx.label}: ${fcc(val)}`;
                            },
                          },
                        },
                      },
                    }}
                  />
                </div>
              </div>
            )}
          </div>
        </GlassSurface>

        <GlassSurface className="p-5">
          <span className="text-[11px] font-semibold tracking-[0.08em] uppercase text-zinc-500">
            Monthly Trends
          </span>
          <div className="mt-3">
            {!barData ? (
              <div className="flex flex-col items-center justify-center py-10 text-zinc-600">
                <TrendingUp className="w-8 h-8 mb-2 opacity-30" />
                <span className="text-xs">No trend data this period</span>
              </div>
            ) : (
              <div className="h-[220px]">
                <Bar
                  data={barData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        position: 'top',
                        labels: { color: '#a1a1aa', font: { size: 10 }, padding: 10, usePointStyle: true, pointStyleWidth: 8 },
                      },
                      tooltip: {
                        backgroundColor: 'rgba(24, 24, 27, 0.95)',
                        titleColor: '#e4e4e7',
                        bodyColor: '#a1a1aa',
                        borderColor: 'rgba(63, 63, 70, 0.5)',
                        borderWidth: 1,
                        cornerRadius: 8,
                        padding: 10,
                      },
                    },
                    scales: {
                      x: { ticks: CHART_AXIS.ticks, grid: { display: false }, border: { display: false } },
                      y: { ticks: { ...CHART_AXIS.ticks, maxTicksLimit: 5 }, grid: CHART_AXIS.grid, border: { display: false } },
                    },
                  }}
                />
              </div>
            )}
          </div>
        </GlassSurface>
      </motion.div>

      {/* Account Summary */}
      <motion.div variants={riseItem} className="space-y-4">
        <span className="text-[11px] font-semibold tracking-[0.08em] uppercase text-zinc-500 block">
          Accounts
        </span>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {personalAccounts.map(account => {
            const accountWallets = activeWallets.filter(w => w.account_id === account.id);
            const convertedBalance = convertAmount(account.balance, account.currency, displayCurrency);
            return (
              <GlassSurface key={account.id} interactive className="p-4 text-left">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="text-sm font-semibold text-zinc-200">{account.name}</p>
                    <span className="text-[10px] text-zinc-500 uppercase tracking-wider">{account.type}</span>
                  </div>
                  <p className="text-base font-bold tabular-nums text-white">{fcc(convertedBalance)}</p>
                </div>
                {accountWallets.length > 0 && (
                  <div className="space-y-1 mt-2 pt-2 border-t border-zinc-700/30">
                    {accountWallets.slice(0, 3).map(w => (
                      <div key={w.id} className="flex items-center justify-between text-xs">
                        <span className="text-zinc-400 truncate">{w.name}</span>
                        <span className="tabular-nums text-zinc-300">{fcc(convertAmount(w.balance, w.currency, displayCurrency))}</span>
                      </div>
                    ))}
                  </div>
                )}
              </GlassSurface>
            );
          })}
        </div>

        {custodialAccounts.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <div className="w-1 h-4 rounded-full bg-amber-400" />
              <span className="text-[11px] font-semibold tracking-[0.08em] uppercase text-amber-400">
                Holding for others
              </span>
              <span className="text-[10px] text-zinc-600">Not counted in net worth</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {custodialAccounts.map(account => {
                const convertedBalance = convertAmount(account.balance, account.currency, displayCurrency);
                return (
                  <GlassSurface key={account.id} className="p-4 border-l-2 border-amber-500/40">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="text-sm font-semibold text-zinc-200">{account.name}</p>
                        <span className="text-[10px] text-zinc-500 uppercase tracking-wider">Custodial</span>
                      </div>
                      <p className="text-base font-bold tabular-nums text-zinc-400">{fcc(convertedBalance)}</p>
                    </div>
                  </GlassSurface>
                );
              })}
            </div>
          </div>
        )}
      </motion.div>
    </motion.div>
  );
}
