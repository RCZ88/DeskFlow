import { useState } from 'react';
import { useNumberMask } from '../../context/NumberMaskContext';
import { maskNumber } from '../../utils/maskNumber';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Wallet, Banknote, CreditCard, Landmark, PiggyBank, X, Edit3, Archive, Trash2, ArchiveRestore, ChevronDown } from 'lucide-react';
import { GlassCard } from '../GlassCard';
import { SectionHeader } from '../SectionHeader';
import { EmptyState } from '../EmptyState';
import { CURRENCIES, getCurrencyInfo, convertAmount, formatCurrency as fmtCurrency } from './currency-data';
import type { FinanceAccount, FinanceWallet } from './finance-types';

interface AccountsTabProps {
  accounts: FinanceAccount[];
  wallets: FinanceWallet[];
  loading: boolean;
  error?: string | null;
  onRetry?: () => void;
  displayCurrency: string;
  onCreateAccount: (data: {
    name: string; type: FinanceAccount['type']; description?: string;
    icon?: string; color?: string; currency?: string; balance?: number;
  }) => Promise<boolean>;
  onCreateWallet: (data: {
    account_id: number; name: string; type: string; provider?: string;
    last_four?: string; balance?: number; currency?: string;
  }) => Promise<boolean>;
  onArchiveWallet: (id: number) => Promise<boolean>;
  onUpdateWallet: (data: { id: number; name: string; type: string; provider?: string; last_four?: string; balance?: number; currency?: string }) => Promise<boolean>;
  onDeleteAccount?: (id: number) => Promise<boolean>;
  onDeleteWallet?: (id: number) => Promise<boolean>;
  onViewArchived?: () => void;
  archivedCount?: number;
}

const accountTypeLabels: Record<string, string> = {
  personal: 'Personal',
  joint: 'Joint',
  custodial: 'Holding',
  business: 'Business',
};

const accountTypeColor: Record<string, string> = {
  personal: 'emerald',
  joint: 'pink',
  custodial: 'amber',
  business: 'pink',
};

const walletMeta: Record<string, { icon: any; label: string; color: string }> = {
  bank: { icon: Landmark, label: 'Bank', color: '#3B82F6' },
  debit_card: { icon: CreditCard, label: 'Debit Card', color: '#10B981' },
  credit_card: { icon: CreditCard, label: 'Credit Card', color: '#F59E0B' },
  crypto: { icon: Wallet, label: 'Crypto', color: '#8B5CF6' },
  cash: { icon: PiggyBank, label: 'Cash', color: '#EC4899' },
  ewallet: { icon: Banknote, label: 'E-Wallet', color: '#06B6D4' },
  other: { icon: Wallet, label: 'Other', color: '#6B7280' },
};

export function AccountsTab({ accounts, wallets, loading, error, onRetry, displayCurrency, onCreateAccount, onCreateWallet, onArchiveWallet, onUpdateWallet, onDeleteAccount, onDeleteWallet, onViewArchived, archivedCount }: AccountsTabProps) {
  const { showNumbers, maskMode, maskFixedValue } = useNumberMask();
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [showCreateWallet, setShowCreateWallet] = useState<number | null>(null);
  const [showEditWallet, setShowEditWallet] = useState<FinanceWallet | null>(null);
  const [swipingWallet, setSwipingWallet] = useState<number | null>(null);

  const formatConverted = (amount: number, fromCurrency: string) => {
    return fmtCurrency(convertAmount(amount, fromCurrency, displayCurrency), displayCurrency);
  };

  const handleSwipeArchive = async (w: FinanceWallet) => {
    await onArchiveWallet(w.id);
    setSwipingWallet(null);
  };

  if (error) {
    return (
      <div className="p-5 space-y-4">
        <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-5 text-center">
          <p className="text-sm text-red-400 mb-2">{error}</p>
          {onRetry && (
            <button
              onClick={onRetry}
              className="px-4 py-2 rounded-lg bg-red-500/15 text-red-400 hover:bg-red-500/25 text-xs font-medium transition-colors focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950"
            >
              Retry
            </button>
          )}
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="space-y-3 p-5">
        {[1,2,3].map(i => (
          <div key={i} className="animate-pulse bg-zinc-800/60 rounded-xl h-24" />
        ))}
      </div>
    );
  }

  if (!accounts.length) {
    return (
      <div className="p-5">
        <EmptyState
          icon={<Wallet className="w-12 h-12" />}
          title="No accounts"
          description="Create an account to start tracking your wallets"
          action={{ label: 'Create Account', onClick: () => setShowCreate(true) }}
        />
        {showCreate && (
          <CreateAccountModal
            onClose={() => setShowCreate(false)}
            onSave={onCreateAccount}
          />
        )}
      </div>
    );
  }

  return (
    <div className="p-5 space-y-4">
      <SectionHeader
        title="Accounts"
        icon={<Wallet className="w-4 h-4" />}
        action={
          <div className="flex items-center gap-2">
            {onViewArchived && (archivedCount ?? 0) > 0 && (
              <button
                onClick={onViewArchived}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800/50 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-700/50 text-xs font-medium transition-colors focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950"
              >
                <ArchiveRestore className="w-3.5 h-3.5" />
                Archived ({archivedCount})
              </button>
            )}
            <button
              onClick={() => setShowCreate(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/25 text-xs font-medium transition-colors focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950"
            >
              <Plus className="w-3.5 h-3.5" />
              New Account
            </button>
          </div>
        }
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {accounts.filter(a => !a.is_archived).map(account => {
          const accountWallets = wallets.filter(w => w.account_id === account.id && !w.is_archived);
          const isExpanded = expandedId === account.id;
          const accent = accountTypeColor[account.type] as any;

          return (
            <motion.div
              key={account.id}
              layout={false}
              transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
            >
              <GlassCard
                variant="interactive"
                accent={accent}
                onClick={() => setExpandedId(isExpanded ? null : account.id)}
                className="!p-4"
              >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${account.color}20` }}>
                        <Wallet className="w-5 h-5" style={{ color: account.color }} />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-medium text-white">{account.name}</p>
                          <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                            accent === 'custodial' ? 'bg-amber-500/10 text-amber-400' :
                            accent === 'business' ? 'bg-blue-500/10 text-blue-400' :
                            accent === 'joint' ? 'bg-purple-500/10 text-purple-400' :
                            'bg-emerald-500/10 text-emerald-400'
                          }`}>
                            {accountTypeLabels[account.type] || account.type}
                          </span>
                        </div>
                        <p className="text-[11px] text-zinc-500">
                          {accountWallets.length} wallet{accountWallets.length !== 1 ? 's' : ''}
                          {account.description && ` \u00b7 ${account.description}`}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="text-right">
                        <p className={`text-base font-semibold tabular-nums ${account.balance >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                          {showNumbers ? fmtCurrency(account.balance, account.currency) : maskNumber(fmtCurrency(account.balance, account.currency), maskMode, maskFixedValue)}
                        </p>
                        {account.currency !== displayCurrency && (
                          <p className="text-[10px] text-zinc-500 tabular-nums">
                            {showNumbers ? formatConverted(account.balance, account.currency) : maskNumber(formatConverted(account.balance, account.currency), maskMode, maskFixedValue)} {displayCurrency}
                          </p>
                        )}
                      </div>
                      {onDeleteAccount && (
                        <button
                          onClick={async (e) => { e.stopPropagation(); if (await onDeleteAccount(account.id)) { setExpandedId(null); } }}
                          className="min-h-[44px] min-w-[44px] flex items-center justify-center p-1.5 rounded text-zinc-500 hover:text-red-400 hover:bg-red-500/10 transition-colors focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950"
                          title="Delete account permanently"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>

                <AnimatePresence>
                  {isExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
                      className="overflow-hidden"
                    >
                      <div className="border-t border-zinc-700/30 mt-3 pt-3 space-y-2">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[10px] uppercase tracking-wider text-zinc-500 font-medium">Wallets</span>
                          <button
                            onClick={(e) => { e.stopPropagation(); setShowCreateWallet(account.id); }}
                            className="flex items-center gap-1 px-2 py-0.5 rounded text-[10px] text-emerald-400 hover:bg-emerald-500/10 transition-colors focus-visible:ring-2 ring-emerald-500/50"
                          >
                            <Plus className="w-2.5 h-2.5" />
                            Add
                          </button>
                        </div>
                        {accountWallets.length === 0 ? (
                          <p className="text-xs text-zinc-500 text-center py-3">No wallets yet</p>
                        ) : (
                          accountWallets.map(w => {
                            const meta = walletMeta[w.type] || walletMeta.other;
                            const WalletIcon = meta.icon;
                            return (
                              <div
                                key={w.id}
                                className="group relative overflow-hidden rounded-lg"
                              >
                                <div className="flex items-center justify-between py-2 px-3 bg-zinc-800/30 hover:bg-zinc-800/50 transition-colors duration-150">
                                  <div className="flex items-center gap-2 min-w-0 flex-1">
                                    <div className="w-7 h-7 rounded-md flex items-center justify-center shrink-0" style={{ backgroundColor: `${meta.color}18` }}>
                                      <WalletIcon className="w-3.5 h-3.5" style={{ color: meta.color }} />
                                    </div>
                                    <div className="min-w-0">
                                      <div className="flex items-center gap-1.5">
                                        <span className="text-xs text-zinc-300 truncate">{w.name}</span>
                                        <span className="text-[9px] px-1 rounded-full bg-zinc-800 text-zinc-500">{meta.label}</span>
                                      </div>
                                      {w.last_four && <span className="text-[10px] text-zinc-500">\u2022\u2022\u2022{w.last_four}</span>}
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-2 shrink-0">
                                    <span className={`text-xs font-medium tabular-nums ${w.balance >= 0 ? 'text-zinc-200' : 'text-red-400'}`}>
                                      {showNumbers ? formatConverted(w.balance, w.currency || account.currency) : maskNumber(formatConverted(w.balance, w.currency || account.currency), maskMode, maskFixedValue)}
                                    </span>
                                    <div className="flex gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity duration-150">
                                      <button
                                        onClick={(e) => { e.stopPropagation(); setShowEditWallet(w); }}
                                        className="min-h-[44px] min-w-[44px] flex items-center justify-center p-1.5 rounded text-zinc-500 hover:text-zinc-200 hover:bg-zinc-700 transition-colors focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950"
                                        title="Edit wallet"
                                      >
                                        <Edit3 className="w-3 h-3" />
                                      </button>
                                      <button
                                        onClick={async (e) => { e.stopPropagation(); await onArchiveWallet(w.id); }}
                                        className="min-h-[44px] min-w-[44px] flex items-center justify-center p-1.5 rounded text-zinc-500 hover:text-amber-400 hover:bg-amber-500/10 transition-colors focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950"
                                        title="Archive wallet"
                                      >
                                        <Archive className="w-3 h-3" />
                                      </button>
                                      {onDeleteWallet && (
                                        <button
                                          onClick={async (e) => { e.stopPropagation(); if (await onDeleteWallet(w.id)) { /* done */ } }}
                                          className="min-h-[44px] min-w-[44px] flex items-center justify-center p-1.5 rounded text-zinc-500 hover:text-red-400 hover:bg-red-500/10 transition-colors focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950"
                                          title="Delete wallet permanently"
                                        >
                                          <Trash2 className="w-3 h-3" />
                                        </button>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </GlassCard>
            </motion.div>
          );
        })}
      </div>

      {showCreate && (
        <CreateAccountModal
          onClose={() => setShowCreate(false)}
          onSave={onCreateAccount}
        />
      )}

      {showCreateWallet && (
        <CreateWalletModal
          accountId={showCreateWallet}
          accounts={accounts}
          onClose={() => setShowCreateWallet(null)}
          onSave={onCreateWallet}
        />
      )}

      {showEditWallet && (
        <EditWalletModal
          wallet={showEditWallet}
          onClose={() => setShowEditWallet(null)}
          onSave={onUpdateWallet}
        />
      )}
    </div>
  );
}

export function CreateAccountModal({ onClose, onSave }: {
  onClose: () => void;
  onSave: (data: {
    name: string; type: FinanceAccount['type']; description?: string;
    icon?: string; color?: string; currency?: string; balance?: number;
  }) => Promise<boolean>;
}) {
  const [name, setName] = useState('');
  const [type, setType] = useState<FinanceAccount['type']>('personal');
  const [description, setDescription] = useState('');
  const [currency, setCurrency] = useState('USD');
  const [balance, setBalance] = useState('');
  const [showCurrencyPicker, setShowCurrencyPicker] = useState(false);
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!name) return;
    setSaving(true);
    await onSave({ name, type, description: description || undefined, currency, balance: balance ? parseFloat(balance) : 0 });
    setSaving(false);
    onClose();
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[var(--z-modal)] flex items-center justify-center p-5"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.92 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.92 }}
        transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-sm bg-zinc-900/95 backdrop-blur-xl border border-zinc-700/50 rounded-xl p-5"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-white">New Account</h3>
          <button onClick={onClose} className="min-h-[44px] min-w-[44px] flex items-center justify-center p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-3">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Account name"
            autoFocus
            className="w-full bg-zinc-800/80 border border-zinc-700/50 rounded-lg px-3 py-2.5 text-sm text-white placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950"
          />

          <div className="flex gap-1.5">
            {(['personal', 'joint', 'custodial', 'business'] as const).map(t => (
              <button
                key={t}
                onClick={() => setType(t)}
                className={`flex-1 py-1.5 rounded-lg text-[11px] font-medium capitalize transition-colors focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950 ${
                  type === t ? 'bg-emerald-500/15 text-emerald-400' : 'bg-zinc-800/60 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {t}
              </button>
            ))}
          </div>

          <input
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Description (optional)"
            className="w-full bg-zinc-800/80 border border-zinc-700/50 rounded-lg px-3 py-2.5 text-sm text-white placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950"
          />

          <div className="relative">
            <button
              onClick={() => setShowCurrencyPicker(!showCurrencyPicker)}
              className="absolute left-1 top-1/2 -translate-y-1/2 flex items-center gap-0.5 px-1.5 py-1 rounded text-zinc-300 hover:text-white text-xs font-medium focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950"
            >
              <span>{getCurrencyInfo(currency).symbol}</span>
              <ChevronDown className="w-3 h-3" />
            </button>
            <input
              type="number"
              step="0.01"
              value={balance}
              onChange={(e) => setBalance(e.target.value)}
              placeholder="Initial balance (0.00)"
              className="w-full bg-zinc-800/80 border border-zinc-700/50 rounded-lg pl-14 pr-3 py-2.5 text-sm text-white placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950"
            />
            {showCurrencyPicker && (
              <div className="absolute top-full mt-1 left-0 w-full max-h-44 overflow-y-auto bg-zinc-800 border border-zinc-700/50 rounded-lg z-10">
                {CURRENCIES.map(c => (
                  <button
                    key={c.code}
                    onClick={() => { setCurrency(c.code); setShowCurrencyPicker(false); }}
                    className={`w-full flex items-center gap-2 px-3 py-2 text-xs hover:bg-zinc-700 transition-colors focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950 ${
                      currency === c.code ? 'text-emerald-400 bg-emerald-500/10' : 'text-zinc-300'
                    }`}
                  >
                    <span className="w-6 text-center">{c.symbol}</span>
                    <span className="flex-1 text-left">{c.code}</span>
                    <span className="text-zinc-500">{c.name}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {type === 'custodial' && (
          <p className="text-[10px] text-amber-400/70 mt-3 flex items-center gap-1.5">
            <span className="w-1 h-1 rounded-full bg-amber-400 shrink-0" />
            Custodial balances are excluded from Net Worth calculations
          </p>
        )}

        <div className="flex gap-2 mt-5">
          <button onClick={onClose} className="flex-1 py-2 rounded-lg bg-zinc-800 text-zinc-400 hover:text-white text-sm transition-colors focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950">
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={saving || !name}
            className="flex-1 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-white text-sm font-medium transition-all disabled:opacity-40 disabled:cursor-not-allowed focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950"
          >
            {saving ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mx-auto" /> : 'Create'}
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

export function CreateWalletModal({ accountId, accounts, onClose, onSave }: {
  accountId: number;
  accounts: FinanceAccount[];
  onClose: () => void;
  onSave: (data: {
    account_id: number; name: string; type: string; provider?: string;
    last_four?: string; balance?: number; currency?: string;
  }) => Promise<boolean>;
}) {
  const account = accounts.find(a => a.id === accountId);
  const [name, setName] = useState('');
  const [type, setType] = useState('bank');
  const [provider, setProvider] = useState('');
  const [lastFour, setLastFour] = useState('');
  const [balance, setBalance] = useState('');
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!name) return;
    setSaving(true);
    await onSave({
      account_id: accountId, name, type,
      provider: provider || undefined,
      last_four: lastFour || undefined,
      balance: balance ? parseFloat(balance) : 0,
      currency: account?.currency || 'USD',
    });
    setSaving(false);
    onClose();
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[var(--z-modal)] flex items-center justify-center p-5"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.92 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.92 }}
        transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-sm bg-zinc-900/95 backdrop-blur-xl border border-zinc-700/50 rounded-xl p-5"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-white">New Wallet</h3>
          <button onClick={onClose} className="min-h-[44px] min-w-[44px] flex items-center justify-center p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950">
            <X className="w-4 h-4" />
          </button>
        </div>

        {account && (
          <p className="text-[11px] text-zinc-500 mb-3">Account: <span className="text-zinc-300">{account.name}</span></p>
        )}

        <div className="space-y-3">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Wallet name"
            autoFocus
            className="w-full bg-zinc-800/80 border border-zinc-700/50 rounded-lg px-3 py-2.5 text-sm text-white placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950"
          />

          <div className="grid grid-cols-4 gap-1.5">
            {Object.entries(walletMeta).map(([key, def]) => {
              const Icon = def.icon;
              return (
                <button
                  key={key}
                  onClick={() => setType(key)}
                  className={`flex flex-col items-center gap-1 py-2 px-1 rounded-lg transition-colors focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950 ${
                    type === key ? 'bg-zinc-700/60 ring-1 ring-zinc-500/50' : 'bg-zinc-800/60 hover:bg-zinc-700/40 text-zinc-400'
                  }`}
                >
                  <Icon className="w-4 h-4" style={{ color: type === key ? def.color : undefined }} />
                  <span className="text-[9px] leading-tight text-center">{def.label}</span>
                </button>
              );
            })}
          </div>

          <div className="flex gap-2">
            <input
              value={provider}
              onChange={(e) => setProvider(e.target.value)}
              placeholder="Provider (e.g. Chase)"
              className="flex-1 bg-zinc-800/80 border border-zinc-700/50 rounded-lg px-3 py-2.5 text-sm text-white placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950"
            />
            <input
              value={lastFour}
              onChange={(e) => setLastFour(e.target.value.replace(/\D/g, '').slice(0, 4))}
              placeholder="Last 4"
              maxLength={4}
              className="w-20 bg-zinc-800/80 border border-zinc-700/50 rounded-lg px-3 py-2.5 text-sm text-white placeholder-zinc-500 text-center focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950"
            />
          </div>

          <input
            type="number"
            step="0.01"
            value={balance}
            onChange={(e) => setBalance(e.target.value)}
            placeholder="Current balance (0.00)"
            className="w-full bg-zinc-800/80 border border-zinc-700/50 rounded-lg px-3 py-2.5 text-sm text-white placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950"
          />
        </div>

        <div className="flex gap-2 mt-5">
          <button onClick={onClose} className="flex-1 py-2 rounded-lg bg-zinc-800 text-zinc-400 hover:text-white text-sm transition-colors focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950">
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={saving || !name}
            className="flex-1 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-white text-sm font-medium transition-all disabled:opacity-40 disabled:cursor-not-allowed focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950"
          >
            {saving ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mx-auto" /> : 'Create'}
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

export function EditWalletModal({ wallet, onClose, onSave }: {
  wallet: FinanceWallet;
  onClose: () => void;
  onSave: (data: {
    id: number; name: string; type: string; provider?: string;
    last_four?: string; balance?: number; currency?: string;
  }) => Promise<boolean>;
}) {
  const [name, setName] = useState(wallet.name);
  const [type, setType] = useState(wallet.type);
  const [provider, setProvider] = useState(wallet.provider || '');
  const [lastFour, setLastFour] = useState(wallet.last_four || '');
  const [balance, setBalance] = useState(String(wallet.balance || ''));
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!name) return;
    setSaving(true);
    await onSave({
      id: wallet.id, name, type,
      provider: provider || undefined,
      last_four: lastFour || undefined,
      balance: balance ? parseFloat(balance) : 0,
      currency: wallet.currency || 'USD',
    });
    setSaving(false);
    onClose();
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[var(--z-modal)] flex items-center justify-center p-5"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.92 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.92 }}
        transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-sm bg-zinc-900/95 backdrop-blur-xl border border-zinc-700/50 rounded-xl p-5"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-white">Edit Wallet</h3>
          <button onClick={onClose} className="min-h-[44px] min-w-[44px] flex items-center justify-center p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-3">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Wallet name"
            autoFocus
            className="w-full bg-zinc-800/80 border border-zinc-700/50 rounded-lg px-3 py-2.5 text-sm text-white placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950"
          />

          <div className="grid grid-cols-4 gap-1.5">
            {Object.entries(walletMeta).map(([key, def]) => {
              const Icon = def.icon;
              return (
                <button
                  key={key}
                  onClick={() => setType(key)}
                  className={`flex flex-col items-center gap-1 py-2 px-1 rounded-lg transition-colors focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950 ${
                    type === key ? 'bg-zinc-700/60 ring-1 ring-zinc-500/50' : 'bg-zinc-800/60 hover:bg-zinc-700/40 text-zinc-400'
                  }`}
                >
                  <Icon className="w-4 h-4" style={{ color: type === key ? def.color : undefined }} />
                  <span className="text-[9px] leading-tight text-center">{def.label}</span>
                </button>
              );
            })}
          </div>

          <div className="flex gap-2">
            <input
              value={provider}
              onChange={(e) => setProvider(e.target.value)}
              placeholder="Provider"
              className="flex-1 bg-zinc-800/80 border border-zinc-700/50 rounded-lg px-3 py-2.5 text-sm text-white placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950"
            />
            <input
              value={lastFour}
              onChange={(e) => setLastFour(e.target.value.replace(/\D/g, '').slice(0, 4))}
              placeholder="Last 4"
              maxLength={4}
              className="w-20 bg-zinc-800/80 border border-zinc-700/50 rounded-lg px-3 py-2.5 text-sm text-white placeholder-zinc-500 text-center focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950"
            />
          </div>

          <input
            type="number"
            step="0.01"
            value={balance}
            onChange={(e) => setBalance(e.target.value)}
            placeholder="Current balance"
            className="w-full bg-zinc-800/80 border border-zinc-700/50 rounded-lg px-3 py-2.5 text-sm text-white placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950"
          />
        </div>

        <div className="flex gap-2 mt-5">
          <button onClick={onClose} className="flex-1 py-2 rounded-lg bg-zinc-800 text-zinc-400 hover:text-white text-sm transition-colors focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950">
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={saving || !name}
            className="flex-1 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-white text-sm font-medium transition-all disabled:opacity-40 disabled:cursor-not-allowed focus-visible:ring-2 ring-emerald-500/50 ring-offset-2 ring-offset-zinc-950"
          >
            {saving ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mx-auto" /> : 'Save'}
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}
