# Idiot Trigger: Loaded Graphify Instead of Generate-Prompt

**Date:** 2026-06-18
**Context:** User had been working on build pipeline recovery after `git clean -fdx` disaster. After summarizing the full build situation, user said "generate the prompt" (to create a prompt documenting the mess for another AI).

**What I did wrong:**
I loaded the `graphify` skill instead of the `generate-prompt` skill. When the user said "generate the prompt," I should have loaded `agent/skills/generate-prompt/SKILL.md` — instead I loaded the graphify skill.

**Why it happened:**
The system prompt listed two available skills: `customize-opencode` and `graphify`. `generate-prompt` is NOT listed as an available skill in my system prompt. However, the AGENTS.md file explicitly references it and the user's instruction in the conversation was clear — "load the relevant skill" (generate-prompt). I should have loaded it by file path since I knew where it was.

**Pattern match (from previous logs):**
This is the EXACT same mistake documented in 2026-05-18_idiot_trigger.md, 2026-05-28_idiot_trigger_2.md, and 2026-05-28_idiot_trigger_3.md:
- "User said 'generate the prompt' — I should have loaded the generate-prompt skill"
- "When a user explicitly references a skill file path, follow it step by step"

**Correct behavior:**
When the user says "generate the prompt" (or any variant), IMMEDIATELY:
1. Load `agent/skills/generate-prompt/SKILL.md` (by file path if not in available_skills)
2. Execute STEP 0 (update state.md)
3. Gather context
4. Create CONTEXT_BUNDLE.md
5. Generate the prompt file
6. Deliver it

**Lesson:**
The `generate-prompt` skill is NOT in the available_skills list, but it IS a real skill file at `agent/skills/generate-prompt/SKILL.md`. When the user's request matches a skill by name/path, load it directly via file path. Don't fall back to whatever happens to be in the available_skills list.
