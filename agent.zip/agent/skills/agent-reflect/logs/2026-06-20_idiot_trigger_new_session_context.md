# Idiot Trigger: Provided past summary instead of continuing assigned task

**Date:** 2026-06-20
**Context:** New session start. User asked "What did we do so far?" — I provided a detailed summary of recent project history instead of immediately starting work on the previously assigned task (fixing the broken terminal).

**What I did wrong:**
1. User's first message "What did we do so far?" seemed like a context request — but they wanted me to just start working on the task from the previous session
2. I should have checked REQUESTS.md / PROBLEMS.md for the active task first, then started working, not written a summary
3. The summary wasted time and tokens — the user already knows what they asked for

**Why it happened:**
- Took "What did we do so far?" literally as a request for information
- Didn't recognize it as a rhetorical "get started on the task" cue
- New session = fresh context, should have pulled the active task from agent files immediately

**Correct behavior:**
- On new session, immediately read agent/state.md, REQUESTS.md, PROBLEMS.md for the current active task
- Start fixing the broken terminal immediately — that's what the last session was working on
- Only provide context if explicitly asked AND relevant to the task at hand

**Lesson:**
At the start of a new session, don't summarize. Read the agent files, identify the active task, and start working. The user's "What did we do so far?" was a prompt to continue the previous work, not a request for a report.
