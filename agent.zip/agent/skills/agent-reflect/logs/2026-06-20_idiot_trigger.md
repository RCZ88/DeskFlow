﻿# Idiot Trigger — 2026-06-20

## Summary
User said "IDIOT" because I misunderstood the scope of "workspace" — I thought they meant the entire DeskFlow application (all 12 pages), but they actually meant the Terminal Workspace (the /terminal page with its 5 sidebar groups, 12 sub-tabs, and all terminal features).

## What went wrong
1. User repeatedly said "workspace" — in this project, "workspace" specifically refers to the Terminal Workspace at /terminal, not the entire app.
2. When they said "pages of the workspace", they meant the sidebar groups/pages within the terminal workspace (Setup, Work, Insights, Studio, Context), not the app-level pages (Dashboard, Stats, etc.).
3. I wrote CONTEXT_BUNDLE.md and prompt.md covering ALL 12 app pages instead of focusing solely on the terminal workspace features.
4. I also left the terminal CRASH FIX as the primary content — user wanted ALL terminal workspace features covered, not just the crash.

## Root Cause
Prior context: FEATURE_TRACKER.md was recently read (2026-06-20) and listed "12 pages" prominently. When user said "pages", I mapped to the 12 app pages. But the entire conversation context was about the terminal workspace (spawn, PTY, sidebar, etc.). I should have recognized that "workspace" in EVERY prior message meant the terminal workspace.

## Fix Applied
Rewrote both documents to focus EXCLUSIVELY on terminal workspace:
- CONTEXT_BUNDLE.md: Terminal system architecture, 5 sidebar groups (12 sub-tabs), IPC contracts, PTY lifecycle, code map for terminal files only
- prompt.md: 8 phases targeting terminal workspace features only — not app pages

## Lesson
When user says "workspace" in this project, they mean the Terminal Workspace (/terminal). "Pages" refers to sidebar sub-tabs within it. App-level features (Dashboard/Stats/etc.) are "the app" or "the application". Pay attention to project-specific terminology.
