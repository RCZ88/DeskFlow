# Idiot Trigger: Missing `stream: true` in streaming fetch + no UI wiring

**Date:** 2026-06-18
**Context:** User asked for streaming progress in AI assistant. I added streaming response parsing in `callLLM` but made two critical mistakes.

**What I did wrong:**

1. **Forgot `stream: true` in the request body** — The `callLLM` method sends `body: JSON.stringify({ model, messages, ... })` but never set `body.stream = true`. Without this flag, the API returns a regular JSON response, not an SSE stream. The streaming parser then reads the JSON as one chunk, finds no `data:` lines, extracts no content, and returns `fullContent = ''`. This causes `message.content || 'Done.'` → every response is just "Done."

2. **Didn't wire streaming text to the UI** — The `callLLM` accumulated `fullContent` internally but never emitted the partial text. The `progressCallback` was only called with status strings ("thinking", "executing", "completed"). The `AiChat.tsx` component had no way to show live text. The user expected to see the AI's response token-by-token as it arrives.

**Why it happened:**
- I was too focused on the SSE parsing infrastructure (reader, decoder, line splitting, JSON parsing) and forgot the fundamental step: telling the API to actually stream via `stream: true`
- I assumed the existing `progressCallback` pattern would handle everything, but I only used it for status updates — never for the actual text content
- I didn't trace through the full data flow from API response to UI rendering before considering the task done

**Correct behavior:**
When implementing streaming:
1. **Always add `stream: true` to the request body** — without this, no SSE happens
2. **Wire every text delta to the UI** — each `parsed.choices[0].delta.content` must be emitted through the progress/streaming callback immediately
3. **Test the full chain** — trace: API response → SSE parser → callback → React state → visible text

**Lesson:**
`stream: true` is not optional — it's the flag that tells the API to enter SSE mode. Without it, streaming infrastructure does nothing. Always verify the full data pipeline: if the UI shows nothing but "Done.", check the API request body first.
