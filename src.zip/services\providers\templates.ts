import type { ProviderTemplate } from './types';

export const PROVIDER_TEMPLATES: Record<string, ProviderTemplate> = {
  openrouter: {
    id: 'openrouter',
    label: 'OpenRouter',
    defaultBaseUrl: 'https://openrouter.ai/api/v1/chat/completions',
    auth: { type: 'bearer' },
    staticHeaders: { 'HTTP-Referer': 'https://deskflow.app', 'X-Title': 'DeskFlow' },
    suggestedModels: ['google/gemini-2.0-flash-001', 'deepseek/deepseek-chat-v3-0324'],
    docsUrl: 'https://openrouter.ai/docs',
  },
  cloudflayer: {
    id: 'cloudflayer',
    label: 'CloudFlayer',
    defaultBaseUrl: 'https://api.cloudflayer.ai/v1/chat/completions',
    auth: { type: 'bearer' },
    suggestedModels: [],
  },
  invilier: {
    id: 'invilier',
    label: 'Invilier',
    defaultBaseUrl: 'https://api.invilier.com/v1/chat/completions',
    auth: { type: 'bearer' },
    suggestedModels: [],
  },
  olamah: {
    id: 'olamah',
    label: 'Olamah',
    defaultBaseUrl: 'http://localhost:11434/v1/chat/completions',
    auth: { type: 'bearer' },
    suggestedModels: ['llama3.1', 'qwen2.5'],
  },
  github: {
    id: 'github',
    label: 'GitHub Models',
    defaultBaseUrl: 'https://models.inference.ai.azure.com/chat/completions',
    auth: { type: 'bearer' },
    staticHeaders: { 'Accept': 'application/json' },
    suggestedModels: ['gpt-4o-mini', 'gpt-4o', 'DeepSeek-V3', 'Mistral-large', 'Llama-3.1-70B'],
    docsUrl: 'https://docs.github.com/github-models',
  },
  gemini: {
    id: 'gemini',
    label: 'Google Gemini',
    defaultBaseUrl: 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions',
    auth: { type: 'query', queryParam: 'key' },
    suggestedModels: ['gemini-2.0-flash', 'gemini-2.0-flash-lite'],
    docsUrl: 'https://ai.google.dev/gemini-api/docs/openai',
  },
  custom: {
    id: 'custom',
    label: 'Custom (OpenAI-compatible)',
    defaultBaseUrl: '',
    auth: { type: 'bearer' },
    suggestedModels: [],
  },
};
