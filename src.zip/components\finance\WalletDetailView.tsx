import { useState, useEffect, useMemo, useCallback } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Landmark, CreditCard, Wallet, Banknote, PiggyBank, Save, RefreshCw, AlertTriangle } from 'lucide-react';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Filler } from 'chart.js';
import { Line } from 'react-chartjs-2';
import { GlassSurface } from './_fx/GlassSurface';
import { getCurrencyInfo, formatCurrency as fmtCurrency } from './currency-data';
import type { FinanceWallet, CashDenomination, WalletMetadata, CryptoPrice, CryptoHistoryPoint } from './finance-types';

interface WalletDetailViewProps {
  wallet: FinanceWallet & { metadata?: any };
  displayCurrency: string;
  onBack: () => void;
  onSaveMetadata: (id: number, metadata: Record<string, any>) => Promise<boolean>;
  onUpdateWallet: (data: { id: number; name: string; type: string; provider?: string; last_four?: string; balance?: number; currency?: string }) => Promise<boolean>;
}

const walletMeta: Record<string, { icon: any; label: string; color: string }> = {
  bank: { icon: Landmark, label: 'Bank', color: '#3B82F6' },
  debit_card: { icon: CreditCard, label: 'Debit Card', color: '#10B981' },
  credit_card: { icon: CreditCard, label: 'Credit Card', color: '#F59E0B' },
  crypto: { icon: Wallet, label: 'Crypto', color: '#8B5CF6' },
  cash: { icon: PiggyBank, label: 'Cash', color: '#EC4899' },
  ewallet: { icon: Banknote, label: 'E-Wallet', color: '#06B6D4' },
  other: { icon: Wallet, label: 'Other', color: '#6B7280' },
};

const maskField = (val: string | null | undefined): string => {
  if (!val) return '';
  if (val.length <= 4) return val;
  return '\u2022'.repeat(val.length - 4) + val.slice(-4);
};

const DENOMINATIONS: { value: number; label: string }[] = [
  { value: 100, label: '$100' },
  { value: 50, label: '$50' },
  { value: 20, label: '$20' },
  { value: 10, label: '$10' },
  { value: 5, label: '$5' },
  { value: 2, label: '$2' },
  { value: 1, label: '$1' },
  { value: 0.25, label: '\u00d8 25\u00a2' },
  { value: 0.10, label: '\u00d8 10\u00a2' },
  { value: 0.05, label: '\u00d8 5\u00a2' },
  { value: 0.01, label: '\u00d8 1\u00a2' },
];

function CashCounter({ denominations = [], onChange }: {
  denominations: CashDenomination[];
  onChange: (d: CashDenomination[]) => void;
}) {
  const total = useMemo(() => denominations.reduce((s, d) => s + d.value * d.count, 0), [denominations]);

  const updateCount = (idx: number, count: number) => {
    const next = [...denominations];
    next[idx] = { ...next[idx], count: Math.max(0, count) };
    onChange(next);
  };

  return (
    <div className="space-y-2">
      <h4 className="text-xs font-medium text-zinc-400 uppercase tracking-wider">Bill Counter</h4>
      <div className="space-y-1">
        {denominations.map((d, i) => (
          <div key={d.label} className="flex items-center justify-between py-1 px-2 rounded-lg bg-zinc-800/30">
            <span className="text-xs text-zinc-300 w-16">{d.label}</span>
            <div className="flex items-center gap-2">
              <button onClick={() => updateCount(i, d.count - 1)} className="w-6 h-6 rounded flex items-center justify-center text-zinc-400 hover:text-white hover:bg-zinc-700/50 text-sm">-</button>
              <span className="text-xs tabular-nums text-zinc-200 w-8 text-center">{d.count}</span>
              <button onClick={() => updateCount(i, d.count + 1)} className="w-6 h-6 rounded flex items-center justify-center text-zinc-400 hover:text-white hover:bg-zinc-700/50 text-sm">+</button>
            </div>
            <span className="text-xs tabular-nums text-zinc-400 w-20 text-right">{fmtCurrency(d.value * d.count, 'USD', 2)}</span>
          </div>
        ))}
      </div>
      <div className="flex justify-between items-center pt-2 border-t border-white/5">
        <span className="text-xs font-medium text-zinc-300">Total</span>
        <span className="text-sm font-semibold text-white tabular-nums">{fmtCurrency(total, 'USD', 2)}</span>
      </div>
    </div>
  );
}

type EditableField = string | number | boolean | null | undefined;

function FieldRow({ label, value, onChange, type = 'text', masked = false }: {
  label: string;
  value: EditableField;
  onChange?: (v: string) => void;
  type?: string;
  masked?: boolean;
}) {
  const display = masked ? maskField(String(value ?? '')) : String(value ?? '');
  return (
    <div className="flex items-center justify-between py-2 px-3 rounded-lg bg-zinc-800/20 hover:bg-zinc-800/40 transition-colors">
      <span className="text-xs text-zinc-400">{label}</span>
      {onChange ? (
        <input
          type={type}
          value={String(value ?? '')}
          onChange={e => onChange(e.target.value)}
          className="text-xs text-right bg-transparent text-zinc-200 tabular-nums outline-none w-40 border-b border-white/5 focus:border-[var(--page-accent)] transition-colors"
        />
      ) : (
        <span className="text-xs text-zinc-200 tabular-nums">{display}</span>
      )}
    </div>
  );
}

function BankDetail({ metadata, onChange }: { metadata: Record<string, any>; onChange: (key: string, v: string) => void }) {
  return (
    <div className="space-y-1">
      <FieldRow label="Bank Name" value={metadata.bank_name} onChange={v => onChange('bank_name', v)} />
      <FieldRow label="Branch" value={metadata.branch} onChange={v => onChange('branch', v)} />
      <FieldRow label="Account Number" value={metadata.account_number} masked />
      <FieldRow label="SWIFT" value={metadata.swift} onChange={v => onChange('swift', v)} />
      <FieldRow label="IBAN" value={metadata.iban} onChange={v => onChange('iban', v)} />
      <FieldRow label="Notes" value={metadata.notes} onChange={v => onChange('notes', v)} />
    </div>
  );
}

function DebitCardDetail({ metadata, onChange }: { metadata: Record<string, any>; onChange: (key: string, v: string) => void }) {
  return (
    <div className="space-y-1">
      <FieldRow label="Card Network" value={metadata.card_network} onChange={v => onChange('card_network', v)} />
      <FieldRow label="Issuer" value={metadata.issuer} onChange={v => onChange('issuer', v)} />
      <FieldRow label="Daily Limit" value={metadata.daily_limit ?? ''} onChange={v => onChange('daily_limit', v)} type="number" />
      <FieldRow label="Notes" value={metadata.notes} onChange={v => onChange('notes', v)} />
    </div>
  );
}

function CreditCardDetail({ metadata, onChange }: { metadata: Record<string, any>; onChange: (key: string, v: string) => void }) {
  return (
    <div className="space-y-1">
      <FieldRow label="Card Network" value={metadata.card_network} onChange={v => onChange('card_network', v)} />
      <FieldRow label="Issuer" value={metadata.issuer} onChange={v => onChange('issuer', v)} />
      <FieldRow label="Credit Limit" value={metadata.credit_limit ?? ''} onChange={v => onChange('credit_limit', v)} type="number" />
      <FieldRow label="Billing Day" value={metadata.billing_day ?? ''} onChange={v => onChange('billing_day', v)} type="number" />
      <FieldRow label="Due Day" value={metadata.due_day ?? ''} onChange={v => onChange('due_day', v)} type="number" />
      <FieldRow label="APR (%)" value={metadata.apr ?? ''} onChange={v => onChange('apr', v)} type="number" />
      <FieldRow label="Notes" value={metadata.notes} onChange={v => onChange('notes', v)} />
    </div>
  );
}

function CryptoDetail({ metadata, onChange, wallet, displayCurrency }: {
  metadata: Record<string, any>;
  onChange: (key: string, v: string) => void;
  wallet: FinanceWallet;
  displayCurrency: string;
}) {
  const symbol = getCurrencyInfo(displayCurrency).symbol;
  const [prices, setPrices] = useState<CryptoPrice[]>([]);
  const [history, setHistory] = useState<CryptoHistoryPoint[]>([]);
  const [loadingPrices, setLoadingPrices] = useState(false);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [timeframe, setTimeframe] = useState(7);
  const [lastUpdated, setLastUpdated] = useState<number | null>(null);
  const [stale, setStale] = useState(false);

  const coinId = (metadata.coin_id as string) || '';
  const amount = Number(wallet.balance) || 0;
  const acquisitionPrice = Number(metadata.acquisition_price) || 0;
  const currentPrice = prices[0]?.current_price ?? 0;
  const priceChange24h = prices[0]?.price_change_percentage_24h ?? null;
  const priceChangeAbs = prices[0]?.price_change_24h ?? null;
  const coinName = prices[0]?.name || '';
  const coinSymbol = prices[0]?.symbol?.toUpperCase() || (metadata.symbol as string || '').toUpperCase();
  const currentValue = amount * currentPrice;
  const costBasis = amount * acquisitionPrice;
  const pnl = currentValue - costBasis;
  const pnlPercent = costBasis > 0 ? (pnl / costBasis) * 100 : 0;
  const hasLiveData = prices.length > 0;
  const hasCoinId = Boolean(coinId);

  useEffect(() => {
    ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Filler);
  }, []);

  const fetchPrices = useCallback(async () => {
    if (!coinId) return;
    setLoadingPrices(true);
    setError(null);
    try {
      const result = await (window as any).deskflowAPI?.financeFetchCryptoPrices([coinId]) as CryptoPrice[];
      if (result && result.length > 0) {
        setPrices(result);
        setLastUpdated(Date.now());
        setStale(false);
      }
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoadingPrices(false);
    }
  }, [coinId]);

  const fetchHistory = useCallback(async () => {
    if (!coinId) return;
    setLoadingHistory(true);
    try {
      const result = await (window as any).deskflowAPI?.financeGetCryptoHistory(coinId, timeframe) as CryptoHistoryPoint[];
      if (result) setHistory(result);
    } catch {
      // non-critical
    } finally {
      setLoadingHistory(false);
    }
  }, [coinId, timeframe]);

  useEffect(() => { fetchPrices(); }, [fetchPrices]);
  useEffect(() => { fetchHistory(); }, [fetchHistory]);

  const lineData = useMemo(() => {
    if (history.length === 0) return null;
    const labels = history.map(p => {
      const d = new Date(p.timestamp);
      return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
    });
    const values = history.map(p => p.price);
    const isUp = values.length > 1 && values[values.length - 1] >= values[0];
    const c = isUp ? '16, 185, 129' : '239, 68, 68';
    return {
      labels,
      datasets: [{
        data: values,
        borderColor: isUp ? '#10B981' : '#EF4444',
        backgroundColor: (ctx: any) => {
          if (!ctx.chart?.ctx) return 'transparent';
          const g = ctx.chart.ctx.createLinearGradient(0, 0, 0, 200);
          g.addColorStop(0, `rgba(${c}, 0.25)`);
          g.addColorStop(1, `rgba(${c}, 0)`);
          return g;
        },
        fill: true,
        tension: 0.3,
        pointRadius: 0,
        borderWidth: 2,
      }]
    };
  }, [history]);

  const lineOptions: any = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: '#18181b',
        borderColor: '#27272a',
        borderWidth: 1,
        titleColor: '#a1a1aa',
        bodyColor: '#f4f4f5',
        callbacks: {
          label: (ctx: any) => `${symbol}${ctx.parsed.y.toFixed(2)}`,
        },
      },
    },
    scales: {
      x: {
        display: true,
        grid: { display: false },
        ticks: { color: '#52525b', maxTicksLimit: 8, font: { size: 9 } },
      },
      y: {
        display: true,
        grid: { color: 'rgba(255,255,255,0.03)' },
        ticks: { color: '#52525b', font: { size: 9 }, callback: (v: any) => `${symbol}${v}` },
      },
    },
  };

  const timeAgo = lastUpdated
    ? (() => {
        const s = Math.floor((Date.now() - lastUpdated) / 1000);
        if (s < 60) return `${s}s ago`;
        const m = Math.floor(s / 60);
        return `${m}m ago`;
      })()
    : null;

  if (!hasCoinId) {
    return (
      <div className="space-y-3">
        <div className="space-y-1">
          <FieldRow label="CoinGecko ID" value={metadata.coin_id} onChange={v => onChange('coin_id', v)} />
          <FieldRow label="Symbol" value={metadata.symbol} onChange={v => onChange('symbol', v)} />
          <FieldRow label="Blockchain" value={metadata.blockchain} onChange={v => onChange('blockchain', v)} />
          <FieldRow label="Wallet Address" value={metadata.wallet_address} masked />
          <FieldRow label="Acquisition Price" value={metadata.acquisition_price ?? ''} onChange={v => onChange('acquisition_price', v)} type="number" />
          <FieldRow label="Notes" value={metadata.notes} onChange={v => onChange('notes', v)} />
        </div>
        <div className="py-6 text-center">
          <Wallet className="w-8 h-8 mx-auto text-zinc-600 mb-2" />
          <p className="text-xs text-zinc-500">No CoinGecko ID set. Enter an ID above and press Save to see live prices.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Loading skeleton */}
      {loadingPrices && !hasLiveData && (
        <div className="animate-pulse space-y-3">
          <div className="h-20 bg-zinc-800/20 rounded-lg" />
          <div className="h-[200px] bg-zinc-800/20 rounded-lg" />
        </div>
      )}

      {/* Error banner */}
      {error && !loadingPrices && (
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-red-500/10 text-red-400 text-[11px]">
          <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
          <span>Could not update prices: {error}</span>
        </div>
      )}

      {/* Stale banner */}
      {stale && !error && !loadingPrices && (
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-amber-500/10 text-amber-400 text-[11px]">
          <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
          <span>Showing cached prices from {timeAgo || 'earlier'}</span>
        </div>
      )}

      {/* Portfolio header */}
      <div className="bg-zinc-800/20 rounded-lg p-4 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs text-zinc-400">Portfolio Value</span>
          <span className="text-lg font-semibold text-white tabular-nums">
            {hasLiveData ? `${symbol}${currentValue.toFixed(2)}` : '\u2014'}
          </span>
        </div>
        {hasLiveData && (priceChange24h !== null || priceChangeAbs !== null) && (
          <div className="flex items-center gap-3 text-[11px]">
            {priceChange24h !== null && (
              <span className={priceChange24h >= 0 ? 'text-emerald-400' : 'text-red-400'}>
                24h: {priceChange24h >= 0 ? '+' : ''}{priceChange24h.toFixed(2)}%
              </span>
            )}
            {priceChangeAbs !== null && (
              <span className={priceChangeAbs >= 0 ? 'text-emerald-400' : 'text-red-400'}>
                {priceChangeAbs >= 0 ? '+' : ''}{symbol}{priceChangeAbs.toFixed(2)}
              </span>
            )}
          </div>
        )}
        {hasLiveData && acquisitionPrice > 0 && (
          <div className="text-[11px]">
            <span className={pnl >= 0 ? 'text-emerald-400' : 'text-red-400'}>
              P&amp;L: {pnl >= 0 ? '+' : ''}{symbol}{pnl.toFixed(2)} ({pnlPercent >= 0 ? '+' : ''}{pnlPercent.toFixed(1)}%)
            </span>
          </div>
        )}
      </div>

      {/* Performance chart */}
      {hasCoinId && (
        <div className="space-y-2">
          <div className="flex items-center gap-1.5">
            {[7, 30, 90].map(t => (
              <button
                key={t}
                onClick={() => setTimeframe(t)}
                className={`px-2.5 py-1 rounded text-[10px] font-medium transition-colors ${
                  timeframe === t
                    ? 'bg-[#8B5CF6]/20 text-[#8B5CF6]'
                    : 'text-zinc-500 hover:text-zinc-300 bg-zinc-800/20 hover:bg-zinc-800/40'
                }`}
              >
                {t}d
              </button>
            ))}
          </div>
          <div className="h-[200px]">
            {lineData ? (
              <Line data={lineData} options={lineOptions} />
            ) : loadingHistory ? (
              <div className="h-full animate-pulse bg-zinc-800/20 rounded-lg flex items-center justify-center">
                <span className="text-[10px] text-zinc-600">Loading chart...</span>
              </div>
            ) : (
              <div className="h-full flex items-center justify-center bg-zinc-800/10 rounded-lg">
                <span className="text-[10px] text-zinc-600">No chart data available</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Asset info */}
      {hasLiveData && (
        <div className="bg-zinc-800/20 rounded-lg p-3 space-y-1.5">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs font-medium text-zinc-300">{coinName || coinId}</span>
            {coinSymbol && <span className="text-[10px] text-zinc-500">{coinSymbol}</span>}
          </div>
          <FieldRow label="Amount" value={`${amount.toFixed(amount < 1 ? 6 : 4)} ${coinSymbol || ''}`} />
          <FieldRow label="Current Price" value={`${symbol}${currentPrice.toFixed(2)}`} />
          {acquisitionPrice > 0 && (
            <FieldRow label="Acquisition Price" value={`${symbol}${acquisitionPrice.toFixed(2)}`} />
          )}
          <div className="border-t border-white/5 my-1" />
          <FieldRow label="Value" value={`${symbol}${currentValue.toFixed(2)}`} />
          {acquisitionPrice > 0 && (
            <FieldRow label="P&amp;L" value={`${pnl >= 0 ? '+' : ''}${symbol}${pnl.toFixed(2)} (${pnlPercent >= 0 ? '+' : ''}${pnlPercent.toFixed(1)}%)`} />
          )}
        </div>
      )}

      {/* Wallet fields */}
      <div className="space-y-1">
        <FieldRow label="CoinGecko ID" value={coinId} onChange={v => onChange('coin_id', v)} />
        <FieldRow label="Symbol" value={metadata.symbol} onChange={v => onChange('symbol', v)} />
        <FieldRow label="Blockchain" value={metadata.blockchain} onChange={v => onChange('blockchain', v)} />
        <FieldRow label="Wallet Address" value={metadata.wallet_address} masked />
        <FieldRow label="Acquisition Price" value={acquisitionPrice || ''} onChange={v => onChange('acquisition_price', v)} type="number" />
        <FieldRow label="Notes" value={metadata.notes} onChange={v => onChange('notes', v)} />
      </div>

      {/* Price source */}
      <div className="flex items-center justify-between px-1">
        <span className="text-[10px] text-zinc-600">
          Prices from CoinGecko{timeAgo ? ` \u2022 Updated ${timeAgo}` : ''}
        </span>
        <button
          onClick={fetchPrices}
          disabled={loadingPrices}
          className="text-zinc-500 hover:text-white transition-colors disabled:opacity-50"
        >
          <RefreshCw className={`w-3 h-3 ${loadingPrices ? 'animate-spin' : ''}`} />
        </button>
      </div>
    </div>
  );
}

function EwalletDetail({ metadata, onChange }: { metadata: Record<string, any>; onChange: (key: string, v: string) => void }) {
  return (
    <div className="space-y-1">
      <FieldRow label="Platform" value={metadata.platform} onChange={v => onChange('platform', v)} />
      <FieldRow label="Phone / Email" value={metadata.phone_or_email} onChange={v => onChange('phone_or_email', v)} />
      <FieldRow label="Daily Limit" value={metadata.daily_limit ?? ''} onChange={v => onChange('daily_limit', v)} type="number" />
      <FieldRow label="Notes" value={metadata.notes} onChange={v => onChange('notes', v)} />
    </div>
  );
}

function OtherDetail({ metadata, onChange }: { metadata: Record<string, any>; onChange: (key: string, v: string) => void }) {
  return (
    <div className="space-y-1">
      <FieldRow label="Notes" value={metadata.notes} onChange={v => onChange('notes', v)} />
    </div>
  );
}

function CashDetail({ metadata, onChange, onDenominationsChange }: {
  metadata: Record<string, any>;
  onChange: (key: string, v: string) => void;
  onDenominationsChange: (d: CashDenomination[]) => void;
}) {
  return (
    <div className="space-y-4">
      <CashCounter denominations={metadata.denominations || []} onChange={onDenominationsChange} />
      <FieldRow label="Notes" value={metadata.notes} onChange={v => onChange('notes', v)} />
    </div>
  );
}

export function WalletDetailView({ wallet, displayCurrency, onBack, onSaveMetadata, onUpdateWallet }: WalletDetailViewProps) {
  const meta = walletMeta[wallet.type] || walletMeta.other;
  const WalletIcon = meta.icon;
  const [editName, setEditName] = useState(false);
  const [nameBuf, setNameBuf] = useState(wallet.name);
  const [localMetadata, setLocalMetadata] = useState<Record<string, any>>(wallet.metadata || {});
  const [saving, setSaving] = useState(false);
  const symbol = getCurrencyInfo(displayCurrency).symbol;

  useEffect(() => {
    setLocalMetadata(wallet.metadata || {});
    setNameBuf(wallet.name);
  }, [wallet]);

  const handleMetadataChange = useCallback((key: string, value: string) => {
    setLocalMetadata(prev => ({ ...prev, [key]: value }));
  }, []);

  const handleDenominationsChange = useCallback((d: CashDenomination[]) => {
    setLocalMetadata(prev => ({ ...prev, denominations: d }));
  }, []);

  const handleSave = async () => {
    setSaving(true);
    try {
      if (nameBuf !== wallet.name) {
        await onUpdateWallet({ id: wallet.id, name: nameBuf, type: wallet.type, provider: wallet.provider || undefined, last_four: wallet.last_four || undefined, balance: wallet.balance, currency: wallet.currency });
      }
      await onSaveMetadata(wallet.id, localMetadata);
    } finally {
      setSaving(false);
    }
  };

  const renderDetailBody = () => {
    switch (wallet.type) {
      case 'bank': return <BankDetail metadata={localMetadata} onChange={handleMetadataChange} />;
      case 'debit_card': return <DebitCardDetail metadata={localMetadata} onChange={handleMetadataChange} />;
      case 'credit_card': return <CreditCardDetail metadata={localMetadata} onChange={handleMetadataChange} />;
      case 'crypto': return <CryptoDetail metadata={localMetadata} onChange={handleMetadataChange} wallet={wallet} displayCurrency={displayCurrency} />;
      case 'cash': return <CashDetail metadata={localMetadata} onChange={handleMetadataChange} onDenominationsChange={handleDenominationsChange} />;
      case 'ewallet': return <EwalletDetail metadata={localMetadata} onChange={handleMetadataChange} />;
      default: return <OtherDetail metadata={localMetadata} onChange={handleMetadataChange} />;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 24 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -24 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
    >
      <GlassSurface className="p-5">
        {/* Back + Title + Save */}
        <div className="flex items-center justify-between mb-4">
          <button onClick={onBack} className="flex items-center gap-1.5 text-xs text-zinc-400 hover:text-white transition-colors">
            <ArrowLeft className="w-3.5 h-3.5" />
            Back
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 transition-colors disabled:opacity-50"
          >
            <Save className="w-3 h-3" />
            {saving ? 'Saving...' : 'Save'}
          </button>
        </div>

        {/* Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ backgroundColor: `${meta.color}18` }}>
            <WalletIcon className="w-5 h-5" style={{ color: meta.color }} />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              {editName ? (
                <input
                  autoFocus
                  value={nameBuf}
                  onChange={e => setNameBuf(e.target.value)}
                  onBlur={() => setEditName(false)}
                  onKeyDown={e => e.key === 'Enter' && setEditName(false)}
                  className="text-sm font-medium bg-zinc-800 text-white outline-none px-1 rounded border border-white/10"
                />
              ) : (
                <h3 className="text-sm font-medium text-white cursor-pointer hover:text-zinc-300 transition-colors" onClick={() => setEditName(true)}>{wallet.name}</h3>
              )}
              <span className="text-[10px] px-1.5 py-0.5 rounded-full" style={{ backgroundColor: `${meta.color}18`, color: meta.color }}>{meta.label}</span>
            </div>
            <div className="flex items-center gap-2 mt-0.5">
              {wallet.provider && <span className="text-[10px] text-zinc-500">{wallet.provider}</span>}
              {wallet.last_four && <span className="text-[10px] text-zinc-500">{'\u2022'.repeat(3)}{wallet.last_four}</span>}
            </div>
          </div>
          <div className="text-right">
            {wallet.type === 'crypto' ? (
              <>
                <div className="text-sm font-semibold text-white tabular-nums">
                  {Number(wallet.balance).toLocaleString(undefined, { minimumFractionDigits: 4, maximumFractionDigits: 8 })}
                </div>
                <div className="text-[10px] text-zinc-500">{localMetadata.symbol?.toString().toUpperCase() || wallet.currency}</div>
              </>
            ) : (
              <>
                <div className="text-sm font-semibold text-white tabular-nums">{symbol}{wallet.balance.toFixed(2)}</div>
                <div className="text-[10px] text-zinc-500">{wallet.currency}</div>
              </>
            )}
          </div>
        </div>

        {/* Detail body */}
        {renderDetailBody()}
      </GlassSurface>
    </motion.div>
  );
}
