import {
  type BuildingTier,
  type CityLayout,
  type RoadSegment,
  type Vec2,
  type ParkLot,
} from "./cityGen"

const MODEL_DIR = "/cyber_assets/models"

const BUILDING_MODELS: Record<BuildingTier, string[]> = {
  low: [`${MODEL_DIR}/building-low-a.glb`, `${MODEL_DIR}/building-low-b.glb`],
  med: [`${MODEL_DIR}/building-med-a.glb`, `${MODEL_DIR}/building-med-b.glb`],
  tall: [
    `${MODEL_DIR}/building-tall-a.glb`,
    `${MODEL_DIR}/building-tall-b.glb`,
    `${MODEL_DIR}/building-tall-c.glb`,
  ],
}

export const ALL_BUILDING_MODEL_URLS: string[] = [
  ...BUILDING_MODELS.low,
  ...BUILDING_MODELS.med,
  ...BUILDING_MODELS.tall,
]

const MODEL_URL_BY_TYPE: Record<string, string> = {}
for (const [tier, urls] of Object.entries(BUILDING_MODELS)) {
  for (const url of urls) {
    const name = url.split("/").pop()!.replace(".glb", "")
    MODEL_URL_BY_TYPE[name] = url
  }
}

export function modelUrlForType(modelType: string): string {
  return MODEL_URL_BY_TYPE[modelType] ?? `${MODEL_DIR}/${modelType}.glb`
}

export interface BuildingInstance {
  id: string
  modelUrl: string
  position: [number, number, number]
  rotationY: number
  fit: [number, number, number]
  tier: BuildingTier
  height: number
  floors: number
  heroId?: string
  agentId?: string
  label?: string
  metricValue?: number
  color?: string
  active?: boolean
}

export interface RoadRibbon {
  id: string
  class: string
  center: [number, number, number]
  length: number
  width: number
  rotationY: number
  elevated: boolean
}

export interface TrafficLightPlacement {
  id: string
  position: [number, number, number]
  roadIds: string[]
}

export interface ParkPlacement {
  id: string
  center: [number, number, number]
  width: number
  depth: number
}

export interface SceneModel {
  buildings: BuildingInstance[]
  roads: RoadRibbon[]
  trafficLights: TrafficLightPlacement[]
  parks: ParkPlacement[]
  bounds: { w: number; d: number }
  heroIds: string[]
  terrainHeightAt: (x: number, z: number) => number
}

export function buildSceneFromLayout(
  layout: CityLayout,
  lotMargin: number = 0.88,
  floorHeight: number = 3.2,
  highwayDeckHeight: number = 6,
): SceneModel {
  const buildings: BuildingInstance[] = layout.buildings.map((b) => ({
    id: b.id,
    modelUrl: modelUrlForType(b.modelType),
    position: [b.x, b.y, b.z],
    rotationY: b.rot,
    fit: [b.w * lotMargin, b.height, b.d * lotMargin],
    tier: b.tier,
    height: b.height,
    floors: Math.max(1, Math.round(b.height / floorHeight)),
    heroId: b.dataIndex != null ? `hero-${b.dataIndex}` : undefined,
  }))

  const roads: RoadRibbon[] = layout.roads.map((r) => {
    const cx = (r.a.x + r.b.x) / 2
    const cz = (r.a.z + r.b.z) / 2
    const y = r.elevated
      ? highwayDeckHeight
      : layout.terrainHeightAt(cx, cz) + 0.02
    const rotationY = Math.atan2(r.dir.x, r.dir.z)
    return {
      id: `road-${r.a.x.toFixed(1)}-${r.a.z.toFixed(1)}`,
      class: r.klass,
      center: [cx, y, cz],
      length: r.length + r.width,
      width: r.width,
      rotationY,
      elevated: r.elevated,
    }
  })

  const trafficLights: TrafficLightPlacement[] = layout.intersections.map(
    (ix, i) => ({
      id: `ix-${i}`,
      position: [
        ix.x,
        layout.terrainHeightAt(ix.x, ix.z),
        ix.z,
      ],
      roadIds: [],
    }),
  )

  const parks: ParkPlacement[] = layout.parks.map((p, i) => ({
    id: `park-${i}`,
    center: [
      p.cx,
      layout.terrainHeightAt(p.cx, p.cz),
      p.cz,
    ],
    width: p.w,
    depth: p.d,
  }))

  return {
    buildings,
    roads,
    trafficLights,
    parks,
    bounds: layout.bounds,
    heroIds: layout.heroIds,
    terrainHeightAt: layout.terrainHeightAt,
  }
}
