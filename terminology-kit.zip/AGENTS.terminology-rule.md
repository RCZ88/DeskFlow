## TERMINOLOGY RESOLUTION (run BEFORE acting on any noun that names a place)

This is a HARD rule. Before you create, move, rename, or modify anything that lives
"somewhere" — a page, route, session, chart, subtab, sidebar item, or file — you MUST
first resolve the target word against `agent/dictionary.md`.

1. Identify every noun in the request that names a LOCATION or THING-WITH-A-PLACE
   (e.g. "workspace", "sidebar", "page", "subpage", "AI tools", "line chart").
2. Look each one up in `agent/dictionary.md`. Use the resolved EXACT place.
3. If the term is NOT in the dictionary, or is marked ambiguous and you can't tell
   which meaning applies → STOP and ask one short clarifying question. Do NOT guess a
   location. A wrong-location action is worse than a question.
4. For "which page has feature X?" consult `agent/FEATURE_TRACKER.md`.
5. After you act, if the user corrects a location you got wrong, add/repair the entry
   in `agent/dictionary.md` and emit a `[save-memory]` lesson so it never repeats.

Known traps (do not repeat):
- "workspace" = the Terminal Workspace at `/terminal` and its internal subtabs, NOT the
  app's router sidebar. Never create an app-level route/sidebar item for a "workspace" request.
- "create a page in the workspace" = add a workspace SUBPAGE/subtab (see `terminal_sessions.subpage`),
  NOT a new app route.
- "sidebar" is ambiguous — disambiguate workspace-sidebar vs app-sidebar before touching either.

These files (`dictionary.md`, `FEATURE_TRACKER.md`, `context.md`) are FORCE-LOADED every
prompt via `opencode.json` "instructions" — they are in your context right now. Read them.
Do not claim you don't know a term that is defined there.
