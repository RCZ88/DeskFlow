# dictionary.md — DeskFlow terminology & location resolution

> PURPOSE: resolve ambiguous words to an EXACT place in the app before acting.
> This file is FORCE-INJECTED into every agent prompt (opencode.json instructions).
> Rule (see AGENTS.md): before you create/move/modify anything that lives
> "somewhere", look the noun up HERE first. If it's not here, ASK — do not guess.

## 🔴 High-confusion terms (these have burned us before)

### "workspace"  (DEFAULT meaning in the terminal context)
- MEANS: the **Terminal Workspace** at route `/terminal` — the multi-pane terminal area
  PLUS its own internal 5-group sub-navigation (Setup / Work / Insights / Studio /
  Context). This is NOT the application's left router sidebar.
- "work ON the workspace" / "in the workspace" = work inside `/terminal` and its subtabs.
- DO NOT create app-level routes or items in the App.tsx router sidebar when the user
  says "workspace". Those are different navigations (see "sidebar" below).

### "saved workspace" / "save the workspace" / "list of workspaces"
- MEANS: a snapshot row in the `workspace_state` table (layout + terminal_tabs +
  sidebar_width + active_tab + configs), managed by IPC `workspace:save` / `workspace:list`
  / `workspace:load` / `workspace:delete`.
- It is surfaced in the UI under **Work → Workspaces** subtab.
- "warn before exiting" = prompt to `workspace:save` when leaving `/terminal` with unsaved changes.

### "sidebar"  (AMBIGUOUS — always disambiguate)
- "workspace sidebar" = the in-`/terminal` 5-group sidebar (Setup/Work/Insights/Studio/Context).
- "app sidebar" / "navigation" = the App.tsx router rail (Dashboard, Stats, IDE, Settings…).
- If unqualified and the topic is the terminal workspace → assume the WORKSPACE sidebar.

### "page" vs "subpage"
- App-level "page" = a route (e.g. `/ide`, `/dashboard`). Lives in App.tsx router + sidebar.
- Workspace "subpage" / "subtab" = a section INSIDE `/terminal`, addressed like
  `work/sessions`, `work/map`, `studio/skills` (see `terminal_sessions.subpage`).
- "create a page in the workspace" = add a workspace SUBPAGE/subtab, NOT an app route.

## 🗺️ App page map (route → page → where features live)
| You say… | Route | Page component | Notable sub-areas |
|---|---|---|---|
| dashboard / home / orbit | `/` | DashboardPage | 3D orbit, heatmap, weekly overview, timer |
| stats / app table | `/stats` | StatsPage | app table, charts, session list |
| productivity / focus score | `/productivity` | ProductivityPage | score, focus sessions, trends |
| browser / websites | `/browser` | BrowserActivityPage | domain groups, top sites |
| **IDE projects / "ID projects"** | `/ide` | IDEProjectsPage | project grid, detection, **AI Tools subpage** |
| terminal / **workspace** | `/terminal` | TerminalPage | 5-group sidebar, panes, sessions, map |
| external / sleep | `/external` | ExternalPage | activity grid, sleep, comparison |
| reports / insights | `/reports` | InsightsPage | Day / Weekly / Activities tabs |
| database / tables | `/database` | DatabasePage | analytics + table browser |
| settings | `/settings` | SettingsPage | Category, Colors, General, Tracking, Prompts |

### IDE Projects → "AI Tools" subpage (your line-chart example)
- "AI tools subpage" = the AI usage section inside `/ide` (IDEProjectsPage).
- "line chart" there = AI usage / cost over time (fed by IPC `get-ai-usage-summary`,
  `get-ide-projects-overview`). When the user says "the line chart on AI tools", target
  THIS chart, not a dashboard chart.

## 🧭 Terminal Workspace sub-navigation (the 5 groups)
| Group | Accent | Subtabs (subpage keys) |
|---|---|---|
| Setup | orange | Presets (`setup/presets`), Configs (`setup/configs`) |
| Work | green | Sessions (`work/sessions`), Map (`work/map`), Files (`work/files`), Workspaces (`work/workspaces`) |
| Insights | purple | Analytics (`insights/analytics`), Issues (`insights/issues`), Bugs (`insights/bugs`) |
| Studio | indigo | Skills (`studio/skills`), Design (`studio/design`) |
| Context | amber | Context (`context/context`), Maintenance (`context/maintenance`), Page Context (`context/page`) |

## How to extend this file
- One entry per term that has caused (or could cause) a wrong-location action.
- Format: the word in quotes → MEANS: <exact place> → DO NOT: <the common mistake>.
- Keep it short; this is injected every prompt, so every line costs tokens.
